package com.company;

public class Main {

    public static void main(String[] args) {
        // Titles should be formatted like this:

        /*
        *   ----------------------------------------------------------------------------------------------------
        *                                               Title
        *  ----------------------------------------------------------------------------------------------------
        */

        // Code should be spaced out so that it is easily readable:

        for ( int i = 0; i < 10; i ++ ) {
            System.out.println(i);
        }

    }
}
