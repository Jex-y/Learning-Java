package Hackerrank.CountedLoops;

public class Solution5 {
    public static void main(String[] args) {
        for (int i = 20; i >= 5 ; i-=5) {
            System.out.println(i);
        }
    }
}
