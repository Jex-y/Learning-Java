package Unit1.Notes;

public class Strings {
    public static void main(String[] args) {
    //TODO
    }
}
