package Unit1.Notes;

public class Enums {
    enum Col {
        Green,
        Blue,
        Yellow
    }
     public static void main(String[] args) {
            Col myCol = Col.Green;
        }
    }

