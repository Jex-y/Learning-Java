package Unit1.Notes;

public class Comments {
    public static void main(String[] args) {
        //This is a single line Comment


        /*
        This
        is
        a
        multi
        line
        comment
         */
    }
}
