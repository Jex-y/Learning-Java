package Unit1.Hackerrank.CountedLoops;

public class Solution2 {
    public static void main(String[] args) {
        for (int i = 10; i <= 20; i++){
            System.out.println(i);
        }
        System.out.println("Finished!");
    }
}
