package Unit1.Hackerrank.CountedLoops;

public class Solution4 {
    public static void main(String[] args) {
        for (double i = 10; i <= 20; i += 0.5){
            System.out.println(i);
        }
        System.out.println("Done");
    }
}
