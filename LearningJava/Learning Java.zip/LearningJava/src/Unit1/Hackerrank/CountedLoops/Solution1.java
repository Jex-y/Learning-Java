package Unit1.Hackerrank.CountedLoops;

public class Solution1 {
    public static void main(String[] args) {
        for (int i = 1; i <= 30; i++) {
            System.out.println(i);
        }
    }
}
