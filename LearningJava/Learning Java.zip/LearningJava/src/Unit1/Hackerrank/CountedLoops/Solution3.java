package Unit1.Hackerrank.CountedLoops;

public class Solution3 {
    public static void main(String[] args) {
        for (int i = 30; i <= 50; i+=5){
            System.out.println(i);
        }
        System.out.println("Done");
    }
}
